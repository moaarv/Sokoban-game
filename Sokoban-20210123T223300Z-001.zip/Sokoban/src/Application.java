package Project;


public class Application {
	/**
	 * 
	 * Creates a menu for the Sokoban game
	 */
	public static void main(String [] args) {
		new SokoMenu();
	}

}
